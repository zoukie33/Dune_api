module.exports={
  secret:'DuneCLeFeu',
  sender: 'dune.epitech.contact%40gmail.com',
  emailPass: 'fnbxfzmxfn33',
};
