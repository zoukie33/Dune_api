

exports.checkUserStudent = function(req, idProf, idStudent){

    

};