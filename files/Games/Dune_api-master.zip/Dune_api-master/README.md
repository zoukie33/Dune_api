# Dune_api

<b>ROUTES </b>

<b>/api/v1/profs</b>

give the list of all profesors

<b>/api/v1/profs/1</b>

give the result of the profesor with the id 1


<b>/api/v1/eleves</b>

give the list of all students

<b>/api/v1/eleves/1</b>

give the result of the sudient with the id 1


<b>/api/v1/ecole</b>

give the list of all school

<b>/api/v1/ecole/1</b>

give the result of the school with the id 1


