import React, { Component } from 'react';
import Carte from './Cartes';
import DisplayScreen from './DisplayScreen';
import MainJoueur from './MainJoueur';
import Dice from './dice'
import DeckPiles from './DeckPile';

const UnDeuxTroisStyle = {
    width:"100%",
    height:"100%"
}
const posLeftUp = {x:"5vw", y:"10vh"};
const rotLeftUp = "135";
const posLeftDo = {x:"5vw", y:"90vh"};
const rotLeftDo = "45";
const posRightDo = {x:"95vw", y:"90vh"};
const rotRightDo = "-45";
const posRightUp = {x:"95vw", y:"10vh"};
const rotRightUp = "-135";
const maxCardPerHand = 4;

function initTeams(players) {
    var playersMapped = [];
    players.forEach(player => {
        playersMapped.push({label:player.name, id:player.id, score:0});
    });
    var teams = {
        blue:{
            top:playersMapped[0],
            bot:playersMapped[1],
        },
        red:{
            top:playersMapped[2],
            bot:playersMapped[3],
        }
    }
    return (teams);
}

var default_state;

export default class UnDeuxTrois extends Component {
    constructor(props) {
        super(props);
        
        this.topBlue = React.createRef();
        this.botBlue = React.createRef();
        this.topRed = React.createRef();
        this.botRed = React.createRef();
        this.deck = React.createRef();
        this.screen = React.createRef();
        default_state = {
            refCurrentPlayer:this.topBlue,
            teams:initTeams(this.props.players),
            firstRound:"true",
            scores:[
                {playerRef:this.topBlue, goodChoice:0, badChoice:0},
                {playerRef:this.botBlue, goodChoice:0, badChoice:0},
                {playerRef:this.topRed, goodChoice:0, badChoice:0},
                {playerRef:this.botRed, goodChoice:0, badChoice:0}
            ]
        }
        this.state = default_state;
    }
    
    setTurnTo(ref) {
        this.state.refCurrentPlayer.current.endTurn();
        ref.current.startTurn();
        var tmpstate = this.state;
        tmpstate.refCurrentPlayer = ref;
        this.screen.current.hideGiveCardDialog();
        this.setState(tmpstate);
    }
    checkVictory(ref) {
        const cards = ref.current.state.cards;
        var refValue, isHigher, isLower;
        for (var index in cards) {
            refValue = cards[index].value;
            isLower = false;
            isHigher = false;
            for (var indexTest in cards) {
                const refnb = parseInt(refValue);
                const testnb = parseInt(cards[indexTest].value);
                if ((refnb - 1) === testnb) {
                    isLower = true;
                }
                else if ((refnb + 1) === testnb) {
                    isHigher = true;
                }
            }
            if (isLower && isHigher) {
                return (true);
            }
        }
        return (false);
    }
    sendScores(scores) {
        console.log(scores);
    }
    victory(team) {
        this.screen.current.victory(team);
        this.sendScores(this.state.scores.map((item) => {
            const score = item.goodChoice * 100 / (item.goodChoice + item.badChoice)
            var datalist_item = {
                score: score,
                label: item.playerRef.current.state.player.label,
            };
            return (datalist_item)
        }));
    }
    nextTurn() {
        const curRef = this.state.refCurrentPlayer;
        const check = (curRef == this.topBlue || curRef == this.botBlue) ? this.checkVictory(this.topBlue) || this.checkVictory(this.botBlue) :
            this.checkVictory(this.topRed) || this.checkVictory(this.botRed);
        if (check) {
            if (curRef === this.topBlue || curRef === this.botBlue)
                this.victory("blue");
            else
                this.victory("red");
            return ;
        }
        if (curRef === this.topBlue || curRef === this.botBlue)
            this.screen.current.rotateScreen("red");
        else
            this.screen.current.rotateScreen("blue");
        if (curRef === this.topBlue)
            this.setTurnTo(this.topRed);
        else if (curRef === this.topRed)
            this.setTurnTo(this.botBlue);
        else if (curRef === this.botBlue)
            this.setTurnTo(this.botRed);
        else
            this.setTurnTo(this.topBlue);
    }
    onDiceRolled(diceResult) {
        this.deck.current.setPickableByValue(diceResult, true);
    }
    onCardPicked(value, color) {
        this.deck.current.setPickableByValue(value, false);
        this.deck.current.removeCard(color, value);

        const playersAllowed = [];
        if (this.state.refCurrentPlayer.current.props.player.team === "blue")
            playersAllowed.push(this.topBlue, this.botBlue);
        else
            playersAllowed.push(this.topRed, this.botRed)
        this.screen.current.giveCardDialog(value, color, playersAllowed);
    }
    checkForDoublon(hand, value) {
        var result = false;
        hand.forEach((item) => {
            if (item.value === value)
                result = true;
        });
        return (result);
    }
    isBestGiveChoice(playerGettingTheCard, value, color) {
        const teamColor = this.state.refCurrentPlayer.current.state.player.team;
        var ref1, ref2;
        if (teamColor === "blue") {
            ref1 = this.topBlue;
            ref2 = this.botBlue;
        }
        else {
            ref1 = this.topRed;
            ref2 = this.botRed;
        }
        var handGiven, handIgnored;
        if (playerGettingTheCard === ref1) {
            handGiven = ref1.current.state.cards;
            handIgnored = ref2.current.state.cards;
        }
        else {
            handGiven = ref2.current.state.cards;
            handIgnored = ref1.current.state.cards;
        }
        if (this.checkForDoublon(handGiven, value) == true) {
            if (this.checkForDoublon(handIgnored, value) == false)
                return (0);
                    }
        if (this.numberCombinaison(value, color, handGiven) < this.numberCombinaison(value, color, handIgnored)
            || handGiven.length > handIgnored.length)
            return (0);
        return (1);
    }
    numberCombinaison(value, color, hand) {
        var result = 0;
        for (var indexCard in hand) {
            var card = hand[indexCard];
            if (card.value - 2 >= value || card.value + 2 <= value) {
                result += 1;
            }
        }
    }
    updateScore(ref, goodChoice) {
        var tmpstate = this.state;
        var i = 0;
        while (i < tmpstate.scores.length) {
            if (tmpstate.scores[i].playerRef == ref) {
                if (goodChoice === 1)
                    tmpstate.scores[i].goodChoice += 1;
                else
                    tmpstate.scores[i].badChoice += 1;
            }
            ++i;
        }
        this.setState(tmpstate);
    }
    giveCard(player, value, color) {
        var isbest = this.isBestGiveChoice(player, value, color);
        var tmpstate = this.state;
        tmpstate.lastPlayerAddingCard = player;
        this.setState(tmpstate);
        this.updateScore(this.state.refCurrentPlayer, isbest);
        player.current.addCard(value, color);
    }
    checkMustThrowCard(ref) {
        var hand = ref.current.state.cards;
        if (hand.length === maxCardPerHand)
            return (true);
        return (false);
    }
    render() {
        const mainsparams = [
            {ref:this.topBlue, team:"blue", id:this.state.teams.blue.top.id, label:this.state.teams.blue.top.label, pos:posLeftUp, rot:rotLeftUp, first:"true"},
            {ref:this.botBlue, team:"blue", id:this.state.teams.blue.bot.id, label:this.state.teams.blue.bot.label, pos:posLeftDo, rot:rotLeftDo, first:"false"},
            {ref:this.topRed, team:"red", id:this.state.teams.red.top.id, label:this.state.teams.red.top.label, pos:posRightUp, rot:rotRightUp, first:"false"},
            {ref:this.botRed, team:"red", id:this.state.teams.red.bot.id, label:this.state.teams.red.bot.label, pos:posRightDo, rot:rotRightDo, first:"false"},
        ];
        var mains = mainsparams.map((item) => {
            return (
                <MainJoueur ref={item.ref}
                player={{
                    label:item.label, 
                    id:item.id,
                    team:item.team,
                }}
                first={item.first}
                pos={item.pos}
                rot={item.rot}/>
            );
        });
        return (
            <div style={UnDeuxTroisStyle}>
                <DeckPiles ref={this.deck} onPicked={(value, color) => this.onCardPicked(value, color)}/>
                {mains}
                <DisplayScreen ref={this.screen}
                quit={() => {this.quit()}}
                startover={() => {this.startover()}}
                onDiceRolled={(result) => {this.onDiceRolled(result)}}
                onThrowCard={() => {
                    var card = this.state.lastPlayerAddingCard.current.removeRandomCard();
                    this.deck.current.addCard(card.color, card.value);
                    this.nextTurn();
                }}
                onGiveCard={(player, value, color, afterGiving) => {
                    this.giveCard(player, value, color);
                    const mustThrowCard = this.checkMustThrowCard(player);
                    afterGiving(mustThrowCard);
                    if (mustThrowCard == false) {
                        this.nextTurn();
                    }
                }}
                checkEmpty={(value) => {return (this.deck.current.getPile(value).length === 0);}}
                passTurn={() => {this.nextTurn()}}
                />
            </div>
        );
    }
    quit() {
        const { ipcRenderer } = require('electron')
        // TODO quels scores envoyer ?!
        var message = {
          playerScore1: 20,
          playerScore2: 20,
          playerScore3: 20,
          playerScore4: 20,
        }
        console.log(message);
       ipcRenderer.send('gameEndMessage', message)
        return (<div>done</div>);
    }
    startover() {
        this.setState(default_state);
        this.deck.current.startover();
        this.screen.current.hideVictoryScreen();
        this.topBlue.current.startover();
        this.botBlue.current.startover();
        this.topRed.current.startover();
        this.botRed.current.startover();
        this.setTurnTo(this.topBlue);
    }
}