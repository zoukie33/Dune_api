import React, { Component } from 'react';

export default class Dice extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (<div onClick={() => {console.log("click")}}>
        </div>);
    }
}