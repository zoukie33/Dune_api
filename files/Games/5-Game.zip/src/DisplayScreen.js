import React, { Component } from 'react';
import "./playertoken.css";

const DisplayScreenStyle = {
    position:"absolute",
    width:"25vh",
    height:"15vw",
    
    top:"32vw",
    transform:"translate(-50%,0)",
    overflow:"hidden"
};

const DiceResultDialogStyle = {
    width:"100%",
    fontSize:"2em",
    height:"100%",
}

export default class DisplayScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            victoryTeam:null,
            display:"true",
            rotation:"rotate(90deg)",
            giveCardDialog:"false",
            rollDiceDialog:"true",
            diceResultDialog:"false",
            throwCardDialog:"false",
            cardToGive:null,
            playersAllowed:null,
            lastDiceResult:null,
        }
    }
    hideVictoryScreen() {
        var tmpstate = this.state;
        tmpstate.victoryTeam = null;
        this.setState(tmpstate);
    }
    rollDice(result) {
        var tmpstate = this.state;
        tmpstate.rollDiceDialog = "false";
        var diceValue = result;
        tmpstate.diceResultDialog = "true";
        tmpstate.lastDiceResult = diceValue;
        this.setState(tmpstate);
        this.props.onDiceRolled(diceValue);
    }
    giveCardDialog(value, color, playersAllowed) {
        var tmpstate = this.state;
        tmpstate.giveCardDialog = "true";
        tmpstate.diceResultDialog = "false";
        tmpstate.cardToGive = {value:value, color:color};
        tmpstate.playersAllowed = playersAllowed;
        this.setState(tmpstate);
    }
    hideGiveCardDialog() {
        var tmpstate = this.state;
        tmpstate.giveCardDialog = "false";
        tmpstate.throwCardDialog = "false";
        tmpstate.rollDiceDialog = "true";
        this.setState(tmpstate);
    }
    throwCardDialog() {
        var tmpstate = this.state;
        tmpstate.giveCardDialog = "false";
        tmpstate.throwCardDialog = "true";
        this.setState(tmpstate);
    }
    rotateScreen(toTeam) {
        var tmpstate = this.state;
        if (toTeam === "blue")
            tmpstate.rotation = 'rotate(90deg)';
        else
            tmpstate.rotation = 'rotate(-90deg)';
        var tmpstate = this.state;
        this.setState(tmpstate);
    }
    passTurn() {
        var tmpstate = this.state;
        tmpstate.rollDiceDialog = "true";
        tmpstate.diceResultDialog = "false";
        this.setState(tmpstate);
        this.props.passTurn();
    }
    victory(team) {
        var tmpstate = this.state;
        tmpstate.victoryTeam = team;
        this.setState(tmpstate);
    }
    diceResultMessage() {
        if (this.props.checkEmpty(this.state.lastDiceResult) === true) {
            return (<div style={{
                height:"100%",
                width:"100%"
            }}>
                <p style={{
                    fontSize:"0.5em",
                    color:"white",
                }}>Zut ! Tu as fait <b>{this.state.lastDiceResult}</b>, et il n'y a plus de carte de cette valeur !</p>
                <button style = {{
                    width:"80%",
                    textAlign:"center",
                    marginLeft:"auto",
                    marginRight:"auto",
                    fontSize:"0.4em",
                }}
                onClick = {
                    () => {this.passTurn()}
                }>Tu auras plus de chance la prochaine fois !</button>
            </div>)
        }
        const message = <p style={{verticalAlign:"middle", fontSize:"0.6em", color:"white"}}>
        Tu as fait : <b>{this.state.lastDiceResult}</b><br/> Choisis une carte de la même valeur
        </p>;
        return (message);
    }
    throwCard() {
        this.props.onThrowCard();
    }
    AskStartOver() {
        this.props.startover();
    }
    AskQuit() {
        this.props.quit();
    }
    render() {
        if (this.state.display !== "true")
            return (null);
        if (this.state.victoryTeam !== null) {
            return (<div style={{
                position:"fixed",
                width:"80vw",
                height:"80vh",
                borderRadius:"0.2vw",
                left:"50%",
                top:"50%",
                transform:"translate(-50%,-50%)",
                backgroundColor:"white",    
            }}>
                <h1 style={{
                    position:"absolute",
                    left:"50%",
                    top:"50%",
                    transform:"translate(-50%,-50%)",
                }}>
                    L'équipe {(this.state.victoryTeam == "blue") ? "des bleus" : "des rouges"} a gagné !
                </h1>
                <div style={{width:"50%", height:"20%", position:"absolute", bottom:"0", left:"50%", transform:"translate(-50%, 0)", display:"inline"}}>
                    <button style={{borderRadius:"0.5vw", marginRight:"5vh", backgroundColor:"#2a3240", color:"white", border:"0", height:"50%", width:"30%"}} onClick={() => this.AskStartOver()}>Recommencer</button>
                    <button style={{borderRadius:"0.5vw", backgroundColor:"#2a3240", color:"white", border:"0", height:"50%", width:"30%"}} onClick={() => {this.AskQuit()}}>Quitter</button>
                </div>
            </div>);
        }
        return (<div
        className="RotationCenter"
        style={{
            position:"fixed",
            top:"50%",
            left:"50%",
            transform:this.state.rotation
        }}>
            <div
            className="DisplayScreen"
            style={DisplayScreenStyle}>
                {(this.state.giveCardDialog === "true") ?
                    <GiveCardDialog
                        playersRefs={this.state.playersAllowed}
                        onChoose={
                            (ref) => {
                                this.props.onGiveCard(ref, this.state.cardToGive.value, this.state.cardToGive.color,
                                (mustThrowCard) => {
                                    if (mustThrowCard == true) {
                                        this.throwCardDialog();
                                    }
                                    else {
                                        this.hideGiveCardDialog();
                                    }
                                });
                            }
                        }
                    />
                    : null
                }
                {(this.state.rollDiceDialog === "true") ?
                    <RollDiceDialog onRoll={(result) => {this.rollDice(result)}}/>
                    :null
                }
                {(this.state.diceResultDialog === "true") ?
                    <div style={DiceResultDialogStyle}>
                        {this.diceResultMessage()}
                    </div>
                    :null
                }
                {(this.state.throwCardDialog === "true") ?
                    <ThrowCardDialog onDone={() => {this.throwCard()}}/>
                    : null
                }
            </div>
            <div style={{
                position:"fixed",
                left:"50%",
                top:"50%",
                display:"none",
            }}
            id="RollingDiceContainer">
            </div>
        </div>);
    }
}

const ThrowCardDialogStyle = {
    border:"0",
    width:"100%",
    height:"100%",
    fontSize:"1.2em",   
}

class ThrowCardDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }
    render() {
        return (<div style={ThrowCardDialogStyle}>
            <div style={{color:"white"}}>Cette main contient trop de cartes.
            L'une d'entre elles va être replacée sur la table.</div>
            <button
            className="TokenContainerActive"
            style={{
                marginTop:"5px",
                height:"5vh",
                verticalAlign:"middle",
                backgroundColor:"white",
                border:"0",
                borderRadius:"2vh",
            }}
            onClick={() =>  {this.props.onDone()}}>D'accord</button>
        </div>);
    }
}

const RollDiceDialogStyle = {
    border:"0",
    width:"25vh",
    height:"25vh",
    fontSize:"2em",
    borderRadius:"100%",
}

class RollDiceDialog extends Component {
    constructor(props) {
        super(props);
    }
    rollADieAnimation(res) {
        var audio = new Audio(require("./dice.mp3"));
        audio.play();
        this.props.onRoll(res);
    }
    computeRollDice() {
        var diceValue = 1 + Math.floor(Math.random() * 10 % 6);
        return (diceValue);
    }
    render() {
        const numberOfDice = 1;
        const valuesToThrow = null;
        return (<button style={RollDiceDialogStyle} onClick={() => {
            const rollADieResult = this.computeRollDice();
            this.rollADieAnimation(rollADieResult);
            }}
            className="TokenContainerActive2"
            >
            Lancer le Dé
        </button>)
    }
}

class GiveCardDialog extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const displayTab = this.props.playersRefs.map((ref) => {
            return (
                <button style={{display:"block", padding:"0", border:0, borderRadius:"0.5vw", backgroundColor:"white", marginRight:"auto", marginRight:"auto",width:"97%", height:"48%", marginBottom:"2%", fontSize:"1.4em"}} onClick={() => {this.props.onChoose(ref)}}>{ref.current.state.player.label}</button>
            );
        });
        return (
            <div style={{
                height:"100%",
                width:"100%",
            }}>
                <div style={{
                    display:"block",
                    height:"50%",
                    width:"100%",padding:"2%",
                }}>
                    {displayTab}
                </div>
                <div style={{
                    display:"block",
                    height:"50%",
                    width:"100%",
                    fontSize:"1.4em",
                    color:"white",  
                }}>
                    à qui veux-tu donner cette carte ?
                </div>
            </div>
        );
    }
}