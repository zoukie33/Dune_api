import React, { Component } from 'react';

const cardsData = [
    {valeur:"1", couleur:"trefle", img:require('./srccards/1c.png')},
    {valeur:"2", couleur:"trefle", img:require('./srccards/2c.png')},
    {valeur:"3", couleur:"trefle", img:require('./srccards/3c.png')},
    {valeur:"4", couleur:"trefle", img:require('./srccards/4c.png')},
    {valeur:"5", couleur:"trefle", img:require('./srccards/5c.png')},
    {valeur:"6", couleur:"trefle", img:require('./srccards/6c.png')},
    {valeur:"1", couleur:"pique", img:require('./srccards/1s.png')},
    {valeur:"2", couleur:"pique", img:require('./srccards/2s.png')},
    {valeur:"3", couleur:"pique", img:require('./srccards/3s.png')},
    {valeur:"4", couleur:"pique", img:require('./srccards/4s.png')},
    {valeur:"5", couleur:"pique", img:require('./srccards/5s.png')},
    {valeur:"6", couleur:"pique", img:require('./srccards/6s.png')},
    {valeur:"1", couleur:"carreau", img:require('./srccards/1t.png')},
    {valeur:"2", couleur:"carreau", img:require('./srccards/2t.png')},
    {valeur:"3", couleur:"carreau", img:require('./srccards/3t.png')},
    {valeur:"4", couleur:"carreau", img:require('./srccards/4t.png')},
    {valeur:"5", couleur:"carreau", img:require('./srccards/5t.png')},
    {valeur:"6", couleur:"carreau", img:require('./srccards/6t.png')},
    {valeur:"1", couleur:"coeur", img:require('./srccards/1h.png')},
    {valeur:"2", couleur:"coeur", img:require('./srccards/2h.png')},
    {valeur:"3", couleur:"coeur", img:require('./srccards/3h.png')},
    {valeur:"4", couleur:"coeur", img:require('./srccards/4h.png')},
    {valeur:"5", couleur:"coeur", img:require('./srccards/5h.png')},
    {valeur:"6", couleur:"coeur", img:require('./srccards/6h.png')},
];

export default class Carte extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value:props.value,
            color:props.color,
        }
    }
    getCardImage(value, color) {
        var result = null;
        cardsData.forEach(item => {
            if (item.valeur === value && item.couleur === color) {
                result = item.img;
            }
        });
        return (result);
    }
    render() {
        if (this.props.hide === "true")
            return (null);
        var style = {
            width:"20vh",
            height:"20vh",
            position:"relative",
        };
        for (const item in this.props.style) {
            style[item] = this.props.style[item];
        }
        var onClick = () => {};
        if (this.props.onClick !== null)
            onClick = this.props.onClick;
        var path = this.getCardImage(this.props.value, this.props.color)
        return (
            <div style={style}
            onClick={() => {onClick()}}>
                <div style={{
                    marginRight:"auto",
                    marginLeft:"auto",
                    height:"100%",
                    width: 100 * 11 / 17 + "%",
                }}>
                    <img src={path}
                        style={{
                            width:"100%", height:"100%"
                        }}
                        alt={this.props.value + " " + this.props.color + " -> " + this.getCardImage(this.props.value, this.props.color)}
                    />
                </div>
            </div>
        )
    }
}