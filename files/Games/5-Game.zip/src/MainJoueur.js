import React, { Component } from 'react';
import Carte from './Cartes';
import './playertoken.css';

const nb_cartes_180_deg = 6
const max_extended_angle = 135;

class PlayerToken extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        const tokenContainerStyle = {
            width:"10vh",
            height:"10vh",
            transform:"translate(-50%,-50%)",
            borderRadius:"100%",
            backgroundColor:"#2a3240",
        };
        var tokenContainerClassName
        if (this.props.player.team === "blue")
            tokenContainerStyle.border = "solid #b7e9f7 0.5vh";
        else
            tokenContainerStyle.border = "solid #ffcccb 0.5vh";
        if (this.props.active === "active")
            {//tokenContainerStyle.animation = "blink-animation 1s steps(5, start) infinite;";
            tokenContainerClassName="TokenContainerActive"
        }
        else
            tokenContainerClassName="TokenContainer"
        const colorText = (this.props.active === "active") ? "#2a3240": "white";
        return (<div
            className={tokenContainerClassName}
            style={tokenContainerStyle}>
            <div className="tokenContent"
            style={{
                position:"absolute",
                top:"50%",
                left:"50%",
                transform:"translate(-50%,-50%)",
                width:"100%", height:"100%",
            }}>
                <div style={{fontSize:"2vh", fontWeight:"bold", overflow:"hidden", transform:"translate(0%,15%)", width:"100%", height:"100%", color:colorText}}>
                    {this.props.player.label}
                </div>
            </div>
        </div>);
    }
}

var default_state;

export default class MainJoueur extends Component {
    startover() {
        while (this.state.cards.length > 0) {
            this.removeRandomCard();
        }
        var tmpstate = this.state;
        tmpstate.active="false";
        tmpstate.player = this.props.player;
    }
    constructor(props) {
        super(props);
        default_state = {
            cards:[],
            player:this.props.player,
            active:"false",
        }
        this.state = default_state;
        if (this.props.first === "true")
            this.state.active = "true";
    }
    removeRandomCard() {
        var index = 0;
        var tmpstate = this.state;
        var card = tmpstate.cards[index];
        tmpstate.cards.splice(index, 1);
        this.setState(tmpstate);
        return (card);
    }
    addCard(value, color) {
        var tmpstate = this.state;
        tmpstate.cards.push({value:value, color:color});
        this.setState(tmpstate);
    }
    startTurn() {
        var tmpstate = this.state;
        tmpstate.active = "true";
        this.setState(tmpstate);
    }
    endTurn() {
        var tmpstate = this.state;
        tmpstate.active = "false";
        this.setState(tmpstate);
    }
    renderCardList() {
        const list = this.state.cards;
        const angle_max = (list.length > nb_cartes_180_deg) ? max_extended_angle :
            (list.length - 1) * max_extended_angle / nb_cartes_180_deg;
        const incr_angle = (list.length <= 1) ? 0 : angle_max / (list.length - 1);
        const angle_align = 90;
        const base_angle = (180 - angle_max) / 2;
        const resultList = list.map((item, index) => {
            const angle_to_add = index * incr_angle;
            var angle = angle_align + angle_to_add + base_angle;
            const translateInitX = -0.5;
            const translateInitY = 0.15;
            const rayon_cercle = 0.6;
            const angleCosSin = angle - 90;
            const translatetrigoX = Math.cos(angleCosSin * Math.PI / 180) * rayon_cercle;
            const translatetrigoY = Math.sin(angleCosSin * Math.PI / 180) * rayon_cercle;
            const translateX = translateInitX - translatetrigoX;
            const translateY = translateInitY - translatetrigoY;
            const transform = "translate("+ translateX * 100 + "%" + "," + translateY * 100 + "%" + ") " + "rotate(" +  angle + "deg)"
            return (
                <div className="singleCard"
                style={{
                    position:"absolute",
                    left:"50%",
                    bottom:"0",
                    transform: transform
                }}>
                    <Carte className={"cartenb" + index} value={item.value} color={item.color}/>
                </div>
            );
        })
        return (
            <div className="CardsList"
                style={{
                    width:"100%",
                    height:"100%"
            }}>
                {resultList}
            </div>
        )
    }
    render() {
        const active = (this.state.active === "true" ) ? "active" : "inactive"
        const r = this.props.rot + "deg";
        var list = this.renderCardList();
        return (
            <div className="handBoxRotationCenter"
            style={{
                transform:"rotate(" + r + ")",
                position:"absolute",
                width:0,
                height:0,
                left:this.props.pos.x,
                top:this.props.pos.y,
            }}
            >
                <div className="handBox"
                    style={{
                        position:"absolute",
                        transform:"translate(-50%,-100%)",
                        width:"50vh",
                        height:"30vh",
                }}>
                    <div className="handShape"
                        style={{
                            width:"100%",
                            height:"100%"
                    }}>
                        {list}
                    </div>
                </div>
                <div className="playerTokenContainer"
                    style={{
                        position:"absolute",
                        width:"0", height:"0"
                }}>
                    <PlayerToken player={this.props.player} active={active}/>
                </div>
            </div>
        );
    }
}