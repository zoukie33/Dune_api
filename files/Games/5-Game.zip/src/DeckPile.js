import React, { Component } from 'react';
import Carte from './Cartes';

const DeckPilesContainerStyle = {
    position:"fixed",
    top:"50%",
    left:"50%",
    width:"70vw",
    height:"80vh",
    transform:"translate(-50%,-50%)",
    overflowY:"hidden"
};

const DeckPilesListStyle = {
    left:"50%",
    top:"50%",
    position:"relative",
    width:"auto",
    height:"100%",
    transform:"translate(-50%,-50%)"
}

var default_state;

export default class DeckPiles extends Component {
    startover() {
        this.setState(default_state);
    }
    constructor(props) {
        super(props);
        const piles = [
            {colors:["trefle","pique","carreau","coeur"], value:1, pickable:false},
            {colors:["trefle","pique","carreau","coeur"], value:2, pickable:false},
            {colors:["trefle","pique","carreau","coeur"], value:3, pickable:false},
            {colors:["trefle","pique","carreau","coeur"], value:4, pickable:false},
            {colors:["trefle","pique","carreau","coeur"], value:5, pickable:false},
            {colors:["trefle","pique","carreau","coeur"], value:6, pickable:false},
        ]
        default_state = {
            piles:piles
        };
        this.state = default_state;
        this.refTab = [];
        for (var i = 1; i < 7; ++i) {
            this.refTab.push({value:i, ref:React.createRef()});
        }
    }
    getPile(value) {
        var result = [];
        this.state.piles.forEach((item) => {
            if (""+ item.value === ""+value)
                result = item.colors;
        });
        return (result);
    }
    addCard(color, value) {
        var tmpstate = this.state;
        var tmppiles = tmpstate.piles;
        for (var index in tmppiles) {
            if ("" + tmppiles[index].value === "" + value) {
                tmppiles[index].colors.push(color);
            }
        }
        tmpstate.piles = tmppiles;
        this.setState(tmpstate);
    }
    removeCard(colorofcardtoremove, valueofcardtoremove) {
        valueofcardtoremove = "" + valueofcardtoremove;
        const result = this.state.piles.map((pile) => {
            if ("" + pile.value !== valueofcardtoremove)
                return (pile);
            var rowToChange = {colors:[], value:pile.value, pickable:false}
            for (var color in pile.colors) {
                if (pile.colors[color] !== colorofcardtoremove)
                    rowToChange.colors.push(pile.colors[color]);
            }
            return (rowToChange);
        });
        var tmpstate = this.state;
        tmpstate.piles = result;
        this.setState(tmpstate);
        for (var tmp in this.state.piles) {
            const ref = this.getPileRef(this.state.piles[tmp].value);
            ref.current.updateColors(this.state.piles[tmp].colors);
        }
    }
    setPickableByValue(value, pickable) {
        var tmpstate = this.state;
        const list = tmpstate.piles;
        for (var item in list) {
            if (list[item].value === value)
                list[item].pickable = pickable;
        }
        tmpstate.piles = list;
        this.setState(tmpstate);
    }
    getPileRef(value) {
        const ref = this.refTab.find((item) => {
            return (item.value === value);
        });
        return (ref);
    }
    renderPiles() {
        const list = this.state.piles;
        const result = list.map((value) => {
            return (<DeckPile
                pickable={value.pickable}
                colors={value.colors}
                value={"" + value.value}
                onPicked={(value, color) => {this.props.onPicked(value, color)}}
                ref={this.getPileRef(value.value)}
            />);
        });
        return (result);
    }
    render() {
        return (
            <div
            className="DeckPilesContainer"
            style={DeckPilesContainerStyle}>
                <div
                className="DeckPilesList"
                style={DeckPilesListStyle}>
                    {this.renderPiles()}
                </div>
            </div>
        );
    }
}

class DeckPile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            colors:this.props.colors
        }
    }
    updateColors(colors) {
        const tmpstate = this.state;
        tmpstate.colors = colors;
        this.setState(tmpstate);
    }
    renderCards() {
        const result = ["pique", "trefle", "coeur", "carreau"].map((item, index) => {
            const transform = "translate(0%, -" + index * 30 + "%";
            const pickableAction = (this.props.pickable === true) ? () => this.props.onPicked(this.props.value, item) : null;
            return (<div className={this.props.value + item} style={{transform:transform}}>
                <Carte value={this.props.value} color={item} onClick={pickableAction} hide={this.props.colors.includes(item) ? "false" : "true"}/>
            </div>);
        })
        return (result);
    }
    render() {
        return (
            <div
            className="DeckPile"
            style={{
                display:"inline-block",
                position:"relative",
                verticalAlign:"middle",
                paddingTop:this.props.colors.length * 2 + "%"
                //transform:"translate(0%," + this.state.colors.length * 2 + "%)"
            }}>
                {this.renderCards()}
            </div>
        );
    }
}