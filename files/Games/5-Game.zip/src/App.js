import React from 'react';
import logo from './logo.svg';
import UnDeuxTrois from './UnDeuxTrois'
import './App.css';

function mockupInputPlayers() {
  return ([
    {
      name:"Joueur 1",
      id:0
    },
    {
      name:"Joueur 2",
      id:1
    },
    {
      name:"Joueur 3",
      id:2
    },
    {
      name:"Joueur 4",
      id:3
    }
  ]);
}

function App() {
  return (
    <div className="App" style={{
      position:"absolute",
      left:"0",
      top:"0",
      width:"100%",
      height:"100%",
      backgroundColor:"#2a3240",
      position:"absolute",
      overflow:"hidden"
    }}>
      <UnDeuxTrois players={mockupInputPlayers()}/>
    </div>
  );
}

export default App;
