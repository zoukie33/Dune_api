import React, { Component } from 'react';
import { Grid, Button, Paper } from '@material-ui/core';

const CompteClassePlateStyle = {
    position:"fixed",
    width:"85vh",
    left:"50%",
    top:"50%",
    transform:"translate(-50%,-50%)",
    height:"85vh"
};

const CompteClassePlateContainerStyle = {
    left:"20%",
    right:"20%",
    top:"2%",
    bottom:"2%",
    paddingTop:"2.5%",
    paddingLeft:"2.5%",
    paddingRight:"2.5%",
    paddingBottom:"2%",
    height:"100%",
}

export default class PixelGrid extends Component {
    constructor(props) {
        super(props);
        this.state = {
            map:this.initMap(this.props.grid.grid),
            dictionnary:this.props.grid.colors,
            name:this.props.name
        };
    }
    initMap(input) {
        const map = input.map((line) => {
            const resultline = line.map((item) => {
                const resultitem = {realValue:item, currentValue:null};
                return (resultitem);
            });
            return (resultline)
        });
        return (map);
    }
    changeMap(newGrid) {
        var tmpstate = this.state;
        tmpstate.map = this.initMap(newGrid.grid);
        tmpstate.name = newGrid.name;
        tmpstate.dictionnary = newGrid.colors;
    }
    updateList(newList) {
        var tmpstate = this.state;
        tmpstate.list = newList;
        this.setState(tmpstate);
    }
    lineStyle(length) {
        return ({
            width:"100%",
            height:"100%"
        });
    }
    itemStyle(value, length) {
        const colorlist = this.state.dictionnary.filter((elem) => {
            return (elem.id == value)
        }, value);
        const color = (colorlist === null || colorlist.length == 0) ? "#ffffff" : colorlist[0].value;
        return ({
            backgroundColor:color,
            height:"100%",
            width:"" + (100 / length) + "%"
        });
    }
    containeritemstyle(length) {
        const height = "" +  (100 / length) + "%";
        return ({
            height:height,
            padding:0
        });
    }
    isVictory() {
        const m = this.state.map;
        console.log("matrix", m);
        for (const line in m) {
            console.log("line", m[line]);
            for (const elem in m[line]) {
                if (m[line][elem].currentValue === null || m[line][elem].realValue !== m[line][elem].currentValue)
                    return (false);
            }
        }
        return (true);
    }
    updateCase(line, column) {
        var tmpstate = this.state;
        tmpstate.map[line][column].currentValue = this.props.getCurrentColorId();
        this.setState(tmpstate);
        if (this.isVictory() == true)
            this.props.victory();
    }
    renderGrid() {
        const dico = this.state.dictionnary;
        const linesLen = this.state.map.length;
        const result = this.state.map
        .map((line, linenb) => {
            const len = line.length;
            const lineresult = line
            .map((item, columnnb) => {
                const size = 1000 / len + "%";
                const itemrendered = <Grid item style={this.itemStyle(item.currentValue, len)} onClick={() => this.updateCase(linenb, columnnb)}>
                    <div style={{position:"relative", margin:"auto", top:"50%", bottom:"50%", transform: "translate(0, -50%)", fontSize:size}}>
                        {item.realValue}
                    </div>
                </Grid>;
                return (itemrendered);
            }, dico, len, linenb)
            return (<Grid item style={this.containeritemstyle(linesLen)}>
                <Grid container direction="row" style={this.lineStyle(linesLen)}>{lineresult}</Grid>
            </Grid>);
        }, dico, linesLen);
        return (result);
    }
    render() {
        return (
            <Paper style={CompteClassePlateStyle}>
                <Grid
                    style={CompteClassePlateContainerStyle}
                    alignContent="stretch"
                    container
                    direction="column"
                    spacing={16}
                >
                    {this.renderGrid()}
                </Grid>
            </Paper>
        );
    }
}