import { createMuiTheme } from '@material-ui/core/styles';

export const theme = createMuiTheme({
  root: {
    background: '#FEEFC2',
    minHeight: '100vh'
  },
  typography: {
    useNextVariants: true,
  },
  main: '#FEEFC2',
  primary: '#1D1C35',
  black: '#1D1C35',
  error: '#FEEFC2',
  palette: {
    background: {
      default: '#FEEFC2',
    },
    primary: {
      main: '#FEEFC2',
    },
    secondary: {
      main: '#1D1C35',
      contrastText: '#FEEFC2',
    },
    error: {
      main: '#FEEFC2',
    }
  },
});
