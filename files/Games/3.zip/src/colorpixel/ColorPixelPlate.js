import React, { Component } from 'react';
import { Grid, Button } from '@material-ui/core';

import PixelGrid from './PixelGrid'
import ColorPixelInterface from './ColorPixelInterface';

function rangeRandom(min, max) {
    var result = Math.floor(Math.random() * (max) + min);
    return (result);
}

const groups = {
    grids: [
        {
            name: "pokeball",
            colors: [
                {id:0, value:"#dddddd"},
                {id:1, value:"#ff0000"},
                {id:2, value:"#444444"}
            ],
            grid: [
                [0, 0, 0, 0, 0, 2, 2, 2, 2, 0, 0, 0, 0, 0],
                [0, 0, 0, 2, 2, 1, 1, 1, 1, 2, 2, 0, 0, 0],
                [0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0],
                [0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0],
                [0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0],
                [2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2],
                [2, 1, 1, 1, 1, 2, 0, 0, 2, 1, 1, 1, 1, 2],
                [2, 2, 2, 2, 2, 2, 0, 0, 2, 2, 2, 2, 2, 2],
                [2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 2],
                [0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0],
                [0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0],
                [0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0],
                [0, 0, 0, 2, 2, 0, 0, 0, 0, 2, 2, 0, 0, 0],
                [0, 0, 0, 0, 0, 2, 2, 2, 2, 0, 0, 0, 0, 0],
            ]
        },
        {
            name: "grid2",
            colors: [
                {id:0, value:"#dddddd"},
                {id:1, value:"#bbbbbb"},
                {id:2, value:"#444444"},
            ],
            grid: [
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 0],
                [2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2, 2, 2, 0, 2, 2, 2, 2, 2],
                [2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2],
                [2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2, 2],
                [0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 0],
                [0, 0, 2, 0, 0, 2, 2, 2, 0, 0, 2, 2, 2, 0, 0, 1, 2, 0, 0],
                [0, 2, 0, 0, 2, 2, 0, 0, 2, 2, 0, 0, 2, 2, 0, 0, 1, 2, 0],
                [0, 2, 0, 2, 2, 2, 0, 0, 2, 2, 0, 0, 2, 2, 2, 0, 1, 2, 0],
                [0, 2, 0, 2, 2, 2, 2, 2, 0, 0, 2, 2, 2, 2, 2, 0, 1, 2, 0],
                [0, 2, 0, 0, 2, 2, 2, 0, 0, 0, 0, 2, 2, 2, 0, 0, 1, 2, 0],
                [0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0],
                [0, 2, 0, 0, 0, 0, 0, 2, 2, 2, 2, 0, 0, 0, 0, 1, 2, 0, 0],
                [0, 0, 2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 1, 1, 2, 0, 0],
                [0, 0, 2, 1, 0, 0, 2, 0, 0, 0, 0, 2, 0, 1, 1, 2, 0, 0, 0],
                [0, 0, 0, 2, 1, 1, 0, 2, 2, 2, 2, 0, 1, 1, 2, 0, 0, 0, 0],
                [0, 0, 0, 0, 2, 2, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ]
        },
        {
            name: "grid3",
            colors: [
                {id:0, value:"#cfd1cf"},
                {id:1, value:"#5a5b5a"},
                {id:2, value:"#0f840b"},
                {id:3, value:"#ffb168"},
                {id:4, value:"#a53e29"},
                {id:5, value:"#7a3d30"}
            ],
            grid: [
                [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
                [0, 0, 1, 1, 3, 3, 3, 3, 1, 3, 3, 3, 3, 3, 1, 1, 0, 0],
                [0, 1, 3, 3, 3, 1, 3, 3, 3, 3, 3, 3, 1, 3, 3, 3, 1, 0],
                [1, 3, 1, 3, 1, 3, 3, 3, 3, 1, 3, 3, 3, 3, 3, 3, 3, 1],
                [1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 3, 3, 3, 3, 1],
                [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                [0, 1, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 1, 0],
                [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                [1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 1],
                [1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 1],
                [0, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 0],
                [0, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 0],
                [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                [1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1],
                [1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1],
                [0, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 0],
                [0, 0, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1, 0, 0],
                [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
            ]
        },
        {
            name: "grid3",
            colors: [
                {id:0, value:"#cfd1cf"},
                {id:1, value:"#5a5b5a"},
                {id:2, value:"#0f840b"},
                {id:3, value:"#911f0f"},
                {id:4, value:"#d8b206"},
                {id:5, value:"#c15f09"}
            ],
            grid:[
                [0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 1, 5, 5, 5, 1, 1, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 1, 1, 1, 5, 5, 5, 1, 0, 0, 0, 0, 0],
                [0, 0, 1, 4, 4, 4, 1, 1, 5, 5, 1, 0, 0, 0, 0],
                [0, 0, 1, 1, 1, 4, 4, 4, 1, 5, 5, 1, 0, 0, 0],
                [0, 0, 1, 3, 3, 1, 4, 1, 3, 1, 5, 5, 1, 0, 0],
                [0, 0, 1, 3, 3, 1, 4, 1, 3, 3, 1, 5, 5, 1, 0],
                [0, 1, 4, 1, 1, 4, 4, 4, 1, 1, 4, 1, 5, 1, 0],
                [0, 1, 4, 0, 1, 4, 4, 4, 4, 0, 1, 1, 5, 5, 1],
                [0, 1, 2, 1, 1, 4, 4, 4, 4, 1, 1, 2, 1, 5, 1],
                [0, 1, 2, 2, 4, 4, 1, 1, 4, 4, 2, 2, 1, 5, 1],
                [1, 4, 4, 1, 1, 4, 4, 4, 4, 4, 4, 4, 1, 1, 1],
                [1, 4, 1, 3, 3, 1, 4, 4, 1, 1, 1, 1, 0, 0, 0],
                [1, 4, 1, 3, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0],
                [1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            ]
        }
    ],
    getPixelGrid:function() {
        const ind = rangeRandom(0, this.grids.length);
        var result = this.grids[ind];
        return (result);
    }
};

/*
Graphically : Grid displaying the state of the game.
Also check if the game is done and generate score at the end
props needed are :
 - studentList (Array)
 - dictionnary (object containing colors both in hex and string format. ex: red -> 0xff0000)
 - endOfGame (callback to use at the end of the game to return scores and redirect to menu)
*/
export default class ColorPixelPlate extends Component {
    constructor(props) {
        super(props);
        this.size = 15;
        this.ColorDictionnary = this.props.dictionnary;
        this.CompteClassePlateStyle = {
            margin: "auto",
            display: "none",
            position: "fixed",
            width: "70%",
            marginLeft: "15%",
            padding: "8px",
            textAlign: "center",
            display: "table-cell",
            verticalAlign: "middle",
        };
        this.CompteClassePlateLineStyle = {
            margin: "auto",
            position: "static",
            width: "fit-content",
            verticalAlign: "middle",
        };
        this.state = {
            currentColorId: null,
            currentGrid:groups.getPixelGrid()
        };
        this.interfaceRef = React.createRef();
        this.gridRef = React.createRef();
    }
    getCurrentColorId() {
        return (this.state.currentColorId);
    }
    changeColor(newColor) {
        var tmpState = this.state;
        tmpState.currentColorId = newColor;
        this.setState(tmpState);
    }
    render() {
        return (
            <div style={this.CompteClassePlateStyle} alignContent='center'>
                <PixelGrid grid={this.state.currentGrid} ref={this.gridRef} getCurrentColorId={() => this.getCurrentColorId()} victory={() => this.props.victory()}/>
                <ColorPixelInterface ref={this.interfaceRef} dictionnary={this.state.currentGrid.colors} studentList={this.props.studentList} changeColor={(color) => this.changeColor(color)} />
            </div>
        );
    }
}