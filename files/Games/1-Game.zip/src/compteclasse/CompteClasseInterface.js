import React, { Component } from 'react';
import './assets/colorblink.css';
/*
User Interface of the game : contains 4 buttons (one for each player)
props needed are :
 - ref (a ref used by InvacouleurPlate to fetch score and other datas at the end of game and updating info during it)
 - handler (a callback used to notice InvacouleurPlate that a button have been clicked)
 - dictionnary (object containing colors both in hex and string format. ex: red -> 0xff0000)
 - studentList (Array)
*/
export default class InvacouleurInterface extends Component {
    constructor(props) {
        super(props);
        this.state = {
            buttonTurn:0,
        };
        
        this.buttonsData = [
            { student: this.props.studentList[0], color: this.props.dictionnary[0].key, score: 0, hit: 0, topScore: 0, lastScore: 0 },
            { student: this.props.studentList[1], color: this.props.dictionnary[1].key, score: 0, hit: 0, topScore: 0, lastScore: 0 },
            { student: this.props.studentList[2], color: this.props.dictionnary[2].key, score: 0, hit: 0, topScore: 0, lastScore: 0 },
            { student: this.props.studentList[3], color: this.props.dictionnary[3].key, score: 0, hit: 0, topScore: 0, lastScore: 0 },
        ];
    }
    setTurn(value) {
        var tmpstate = this.state;
        tmpstate.buttonTurn = value;
        this.setState(tmpstate);
    }
    nextTurn() {
        var tmpstate = this.state;
        tmpstate.buttonTurn = (tmpstate.buttonTurn + 1) % 4;
        this.setState(tmpstate);
    }
    /*
    Called by InvacouleurPlate to calculate scores
    */
    getButtonsData = () => {
        var bd = this.buttonsData;
        var result = [
            bd[0],
            bd[1],
            bd[2],
            bd[3]
        ];
        return (result);
    }
    /*
    Called by InvacouleurPlate after updating the grid
    */
    increaseScore = (color, score_to_add) => {
        this.buttonsData.forEach((elem) => {
            if (elem.color === color) {
                elem.score = elem.score + score_to_add;
                if (score_to_add > elem.topScore) {
                    elem.topScore = score_to_add;
                }
                elem.lastScore = score_to_add;
            }
        }, color, score_to_add);
    }
    setButtonStyle(transform, color, left, bottom, right, rounded) {
        var result = {
            transform: transform,
            borderRadius: "10%",
            borderStyle: "solid",
            borderWidth: "5px",
            position: "fixed",
            padding: "8px",
            width: "80px",
            height: "80px",
            borderColor: color,
            left: left,
            bottom: bottom,
            right: right,
        };
        if (rounded) {
            result.borderRadius = "50%";
            result.animation = "colorblink 0.5s infinite"
        }
        return (result);
    }
    setStyle(color1, color2, color3, color4) {
        this.interfaceStyle = {
            position: "fixed",
            top: "0",
            left: "0",
            padding: "8px",
        };
        this.button1Style = this.setButtonStyle("rotate(90deg)", color1, "16px", "30%", "", this.state.buttonTurn === 0);
        this.button2Style = this.setButtonStyle("rotate(1deg)", color2, "20%", "16px", "", this.state.buttonTurn === 1);
        this.button3Style = this.setButtonStyle("rotate(-1deg)", color3, "", "16px", "20%", this.state.buttonTurn === 2);
        this.button4Style = this.setButtonStyle("rotate(-90deg)", color4, "", "30%", "16px", this.state.buttonTurn === 3);
    }
    getButtonsLabels() {
        if (this.buttonsData == null) { // if there is no data, return 4 empty strings so the buttons can be generated properly
            return (["", "", "", ""]);
        }
        return ( //return an array of size 4 containing each student's label (name and firstname). If a label is null, it is replaced by an empty String.
            this.buttonsData.map((value) => {
                return ((value != null && value.student != null) ? value.student.label : "");
            }
            )
        );
    }
    render() {
        var nameTab = this.getButtonsLabels();
        this.setStyle(
            this.props.dictionnary[0].value,
            this.props.dictionnary[1].value,
            this.props.dictionnary[2].value,
            this.props.dictionnary[3].value,
        );
        return (
            <div style={this.interfaceStyle}>
                <div style={this.button1Style}>{nameTab[0]}</div>
                <div style={this.button2Style}>{nameTab[1]}</div>
                <div style={this.button3Style}>{nameTab[2]}</div>
                <div style={this.button4Style}>{nameTab[3]}</div>
            </div>
        );
    }
}