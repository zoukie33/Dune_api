import React, { Component } from 'react';

import { Dialog, DialogTitle, DialogContent, Card, Button, Slide, DialogActions, CardContent, CardHeader } from '@material-ui/core';
import Typography from '@material-ui/core/Typography';

import illustration1 from './assets/00.png';
import illustration2 from './assets/01.png';
import illustration3 from './assets/02.png';

/*
Dialog printed at the start of the game : display 4 slides to explain how to play
*/
export default class InstructionDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            page: 0,
        };
    }
    // prevPage and nextPage can't lead to an overflow because nextButton and prevButton are disabled when the index (page) reach a limit
    /*
    Decrease the index of the displayed page
    */
    prevPage = () => {
        var prev_state = this.state;
        prev_state.page -= 1;
        this.setState(prev_state);
    }
    /*
    Increase the index of the displayed page
    */
    nextPage = () => {
        var prev_state = this.state;
        prev_state.page += 1;
        this.setState(prev_state);
    }
    render() {
        const illustrationStyle = {
            width: "100%",
        };
        return (
            <Dialog open={this.props.open} onClose={this.props.onClose}>
                <DialogTitle>
                    CompteClasse
                </DialogTitle>
                <DialogContent>
                    <Slide direction='right' in={(this.state.page == 0) ? true : false} mountOnEnter unmountOnExit>
                        <Card>
                            <CardHeader title="Comment jouer ?" />
                            <CardContent>
                                <Typography align='center'>
                                    Apprends à compter avec CompteClasse !
                                </Typography>
                                <Typography align='center'>
                                    Sur le plateau, tu vas pouvoir voir plusieurs objets ou animaux ...
                                </Typography>
                                <Typography align='center'>
                                    Chacun votre tour, vous allez devoir compter le nombre d'objets ou animaux répondant à la description de l'énoncé
                                </Typography>
                            </CardContent>
                            <img src={illustration1} style={illustrationStyle} />
                        </Card>
                    </Slide>
                    <Slide direction='right' in={(this.state.page == 1) ? true : false} mountOnEnter unmountOnExit>
                        <Card>
                            <CardHeader title="Comment jouer ?" />
                            <CardContent>
                                <Typography align='center'>
                                    Lorsque c'est ton tour, ton pion est rond et clignotant
                                </Typography>
                            </CardContent>
                            <img src={illustration2} style={illustrationStyle} />
                        </Card>
                    </Slide>
                    <Slide direction='right' in={(this.state.page == 2) ? true : false} mountOnEnter unmountOnExit>
                        <Card>
                            <CardHeader title="Comment jouer ?" />
                            
                            <CardContent>
                                <Typography align='center'>
                                    Quand chacun a joué, la bonne réponse s'affiche.
                                </Typography>
                                <Typography align='center'>
                                    Si tout le monde a bien répondu, la difficulté augmente...
                                </Typography>
                                <Typography align='center'>
                                    Et les scores aussi !
                                </Typography>
                            </CardContent>
                            <img src={illustration3} style={illustrationStyle} />
                        </Card>
                    </Slide>
                </DialogContent>
                <DialogActions>
                    <Button onClick={this.props.onClose}>Commencer</Button>
                    <Button disabled={(this.state.page == 0) ? true : false} onClick={this.prevPage}>Précédent</Button>
                    <Button disabled={(this.state.page == 2) ? true : false} onClick={this.nextPage}>Suivant</Button>
                </DialogActions>
            </Dialog>
        );
    }
}
