import React, { Component } from 'react';

import { Dialog, DialogTitle, DialogContent, Card, Button, Slide, DialogActions, CardContent, CardHeader } from '@material-ui/core';
import Typography from '@material-ui/core/Typography';

export default class GoodAnswerDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
            open:false,
            goodAnswer:0
        };
    }
    showAnswer(value) {
        var tmpState = this.state;
        tmpState.goodAnswer = value;
        tmpState.open = true;
        this.setState(tmpState);
    }
    hideAnswer() {
        var tmpState = this.state;
        tmpState.open = false;
        this.setState(tmpState);
        this.props.onQuit()
    }
    render() {
        return (
            <Dialog open={this.state.open} onClose={() => {this.hideAnswer()}}>
                <DialogTitle>   
                    La bonne réponse était :
                </DialogTitle>
                <DialogContent>
                    <Typography variant='h2' align="center">
                        {this.state.goodAnswer}
                    </Typography>
                </DialogContent>
            </Dialog>
        );
    }
};