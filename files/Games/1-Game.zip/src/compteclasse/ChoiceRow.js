import React, { Component } from 'react';
import { Paper, Grid, Button, Typography } from '@material-ui/core';

const ChoiceRowStyle = {
    position:"fixed",
    top:"56%",
    left:"10vw",
    right:"10vw",
    bottom:"15%"
};

export default class ChoiceRow extends Component {
    constructor(props) {
        super(props);
        this.state = {
            choices:[],
            tag:""
        }
    }
    updateChoices(value, tag) {
        var tmpState = this.state;
        tmpState.choices = value;
        tmpState.tag = tag;
        this.setState(tmpState);
    }
    getItemStyle() {
        var length = this.state.choices.length;
        const nbColumn = (length > 8) ? 8 : length;
        var nbLine = 1;
        while (length > nbColumn) {
            nbLine += 1;
            length -= nbColumn;
        }
        const width = 1 / (nbColumn) * 100;
        const height = 1 / nbLine * 100;
        var result = {
            width:width + "%",
            height:height + "%",
        };
        return (result);
    }
    renderChoices() {
        const handler = this.props.onChoice;
        return (
            this.state.choices.map((value) => {
                return (
                    <Grid item style={this.getItemStyle()}>
                        <Button
                            variant="contained"
                            onClick={() => handler(value.value)}
                            style={{height:"100%", width:"100%"}}
                        >
                            <Typography variant="h1">
                                {value.label}
                            </Typography>
                        </Button>
                    </Grid>
                );
            }, handler)
        );
    }
    render() {
        return(
            <Paper style={ChoiceRowStyle}>
                <Typography align="center" style={{position:"absolute", left:"2.5%", right:"2.5%", height:"15%", top:"2.5%", bottom:"2.5%"}}><span style={{fontSize:"2em"}}>Parmi ces objets, combien sont : {this.state.tag}</span></Typography>
                <Grid container alignContent="center" alignItems="center" style={{position:"absolute", bottom:"5%", left:"1.25%", right:"1.25%", width:"97.5%", height:"75%"}}>
                    {this.renderChoices()}
                </Grid>
            </Paper>
        );
    }
}